# Marquee html 5 tag

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jofiman/pen/JoGXMv](https://codepen.io/Jofiman/pen/JoGXMv).

